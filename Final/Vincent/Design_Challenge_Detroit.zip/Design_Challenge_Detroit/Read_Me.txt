Edit Imports Shapefile:
This is a shapefile of the importing facilities in Detroit, Michigan that imported solid hazardous waste during the entire time period that the data is for.  It was created by copying the coordinates from the given Excel file to another Excel file and adding the XY coordinate data to ArcMap.  These coordinates were then exported as a data file so I could edit the attribute table.  I added the total amount of solid waste imported in tons for the whole time period to the attribute table.

Edit Exports Shapefile:
This shapefile was created the same way as the import shapefile was created.  It includes the locations of Detroit�s exporting facilities and the total amount of solid waste exports in the entire time frame given.  

The Word document has a few articles about environmental injustice and hazardous waste that I found while researching for the Design Challenge.


